from app import create_app
from app.database import init_db
import os

# Initialize database
init_db()

app = create_app()

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=True)
