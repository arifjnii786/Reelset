# ReelSet AI Clipper

**Architecture Pipeline for turning long-form YouTube videos into viral-ready vertical shorts.**

## New Features: Login + Pay-per-Use + Advanced IP Security

- ✅ User registration & login system
- ✅ **Free tier**: First 3 clips free
- ✅ **Pro tier**: Pay **$2** once for **15 reels**
- ✅ Stripe Checkout integration
- ✅ Usage tracking + premium access
- ✅ **Advanced IP Abuse Protection**:
  - One IP/device = max **3 free clips total**
  - Tracks all accounts created from the same IP
  - Blocks temp mail abuse / multiple accounts
  - Shows real-time IP usage in UI

## How IP Protection Works

Every time a user generates a clip:
1. Their **user account** free credit is decremented
2. Their **IP address** free credit is also decremented globally
3. Even if they create 10 new accounts with temp mails, the IP still only has 3 total free clips

This makes it extremely difficult to abuse the free tier.

## Features

- ✅ YouTube URL or direct video upload
- ✅ yt-dlp video download
- ✅ Whisper transcription (timestamped)
- ✅ Librosa audio energy analysis
- ✅ Claude 3.5 Sonnet segment scoring (hook potential)
- ✅ Auto-selection of best 3–5 clips (25–65s)
- ✅ FFmpeg 9:16 vertical crop (smart centering)
- ✅ CapCut-style word-pop captions (dynamic + animated)
- ✅ Clean web UI (mobile-friendly)
- ✅ Ready-to-download MP4 shorts

## Tech Stack

| Layer       | Tech                          |
|-------------|-------------------------------|
| Backend     | Python + Flask                |
| Frontend    | Tailwind CSS + Vanilla JS     |
| AI          | Claude 3.5 Sonnet (via API)   |
| Transcription | OpenAI Whisper              |
| Audio       | Librosa + NumPy               |
| Video       | FFmpeg + MoviePy              |
| Download    | yt-dlp                        |

## Installation (Termux / PC)

```bash
# 1. Clone or copy the project
cd reelset-ai-clipper

# 2. Install dependencies
pip install -r requirements.txt

# 3. Setup environment
cp .env.example .env
# Edit .env and add your CLAUDE_API_KEY
```

### Required API Key

Get your Claude API key from: https://console.anthropic.com/

Add it to `.env`:

```env
CLAUDE_API_KEY=sk-ant-...
```

## Run the App

```bash
python run.py
```

Then open in browser:

```
http://localhost:5000
```

## Usage

1. Paste a YouTube URL or upload an MP4
2. Click **Process**
3. Watch the pipeline run (Whisper → Claude → FFmpeg)
4. Preview, download, or download all clips

## Project Structure

```
reelset-ai-clipper/
├── app/
│   ├── __init__.py
│   ├── routes.py
│   ├── pipeline.py
│   ├── claude_scorer.py
│   ├── video_processor.py
│   └── caption_generator.py
├── templates/
│   └── index.html
├── static/
├── uploads/
├── clips/
├── temp/
├── run.py
├── requirements.txt
└── .env.example
```

## Configuration

Edit `.env`:

```env
CLAUDE_API_KEY=sk-ant-...
MAX_CLIPS=5
CLIP_MIN_DURATION=25
CLIP_MAX_DURATION=65
```

## Notes

- Runs perfectly in Termux (Android) or any Linux/Mac/PC
- Uses `base` Whisper model by default (change to `small` / `medium` for better quality)
- All clips are saved to `clips/<task_id>/`
- Fallback scoring works if Claude API is unavailable

---

Built with ❤️ for creators who want to go viral fast.
