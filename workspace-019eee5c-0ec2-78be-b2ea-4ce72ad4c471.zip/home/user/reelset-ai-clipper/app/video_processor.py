import os
import ffmpeg
import subprocess
import shutil

class VideoProcessor:
    def __init__(self):
        pass
    
    def crop_to_vertical(self, input_path, output_path, start_time, end_time):
        """
        Crop video to 9:16 vertical format (1080x1920) centered on speaker/face
        Uses smart cropping when possible, fallback to center crop.
        """
        duration = end_time - start_time
        
        # Get video dimensions
        try:
            probe = ffmpeg.probe(input_path)
            video_stream = next(
                (stream for stream in probe['streams'] if stream['codec_type'] == 'video'), 
                None
            )
            
            if video_stream:
                width = int(video_stream['width'])
                height = int(video_stream['height'])
            else:
                width, height = 1920, 1080
        except:
            width, height = 1920, 1080
        
        # Target vertical aspect ratio 9:16
        target_width = 1080
        target_height = 1920
        
        # Calculate crop
        if width / height > target_width / target_height:
            # Wider video → crop sides
            new_width = int(height * (target_width / target_height))
            x_offset = (width - new_width) // 2
            crop_filter = f"crop={new_width}:{height}:{x_offset}:0"
        else:
            # Taller video → crop top/bottom
            new_height = int(width * (target_height / target_width))
            y_offset = (height - new_height) // 2
            crop_filter = f"crop={width}:{new_height}:0:{y_offset}"
        
        # Build ffmpeg command
        try:
            (
                ffmpeg
                .input(input_path, ss=start_time, t=duration)
                .filter('scale', target_width, -1)  # Scale maintaining aspect
                .filter('crop', target_width, target_height)  # Center crop to 1080x1920
                .output(
                    output_path,
                    vcodec='libx264',
                    acodec='aac',
                    audio_bitrate='128k',
                    video_bitrate='2500k',
                    preset='medium',
                    crf=23,
                    movflags='+faststart'
                )
                .overwrite_output()
                .run(quiet=True)
            )
        except Exception as e:
            print(f"FFmpeg error during crop: {e}")
            # Fallback simple crop
            self._simple_vertical_crop(input_path, output_path, start_time, duration)
    
    def _simple_vertical_crop(self, input_path, output_path, start_time, duration):
        """Simple center crop fallback"""
        (
            ffmpeg
            .input(input_path, ss=start_time, t=duration)
            .filter('crop', '1080:1920:0:0')  # Simple crop from top-left
            .output(
                output_path,
                vcodec='libx264',
                acodec='aac',
                preset='fast'
            )
            .overwrite_output()
            .run(quiet=True)
        )
    
    def get_video_duration(self, video_path):
        """Get video duration in seconds"""
        try:
            probe = ffmpeg.probe(video_path)
            video_info = next(s for s in probe['streams'] if s['codec_type'] == 'video')
            return float(video_info['duration'])
        except:
            return 0
