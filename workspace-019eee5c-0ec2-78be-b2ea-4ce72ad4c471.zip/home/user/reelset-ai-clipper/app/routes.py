from flask import Blueprint, render_template, request, jsonify, send_from_directory, url_for, session, redirect
from werkzeug.utils import secure_filename
import os
import uuid
import threading
from .pipeline import ReelSetPipeline
from .database import (
    can_generate_clips, record_usage, update_free_clips, get_user_by_id,
    record_ip_usage, link_user_to_ip, get_ip_free_clips_used, can_ip_use_free_clips
)
from .auth import login_required, get_current_user, register_user, login_user, logout_user, hash_password, verify_password
from .stripe_handler import create_checkout_session, verify_payment, handle_stripe_webhook
from .security import (
    get_client_ip, check_rate_limit, generate_device_fingerprint,
    record_device_fingerprint, is_suspicious_device,
    generate_captcha, verify_captcha
)

bp = Blueprint('main', __name__)

pipeline = ReelSetPipeline()

@bp.route('/')
def index():
    user = get_current_user()
    return render_template('index.html', user=user)

@bp.route('/login')
def login_page():
    return render_template('login.html')

@bp.route('/register')
def register_page():
    return render_template('register.html')

@bp.route('/pricing')
def pricing_page():
    user = get_current_user()
    return render_template('pricing.html', user=user)

@bp.route('/upload', methods=['POST'])
@login_required
def upload_video():
    """Handle video upload or YouTube URL with IP-based abuse protection"""
    user = get_current_user()
    data = request.get_json()
    
    if not data:
        return jsonify({'error': 'No data provided'}), 400
    
    # Get real client IP (handles proxies)
    client_ip = request.headers.get('X-Forwarded-For', request.remote_addr)
    if client_ip and ',' in client_ip:
        client_ip = client_ip.split(',')[0].strip()
    
    # Advanced IP abuse protection
    # Check if this IP can still use free credits
    ip_can_use, ip_remaining = can_ip_use_free_clips(client_ip)
    
    # Check user-level limit
    can_generate, user_remaining = can_generate_clips(user['id'], client_ip)
    
    if not can_generate or not ip_can_use:
        total_ip_usage = get_ip_free_clips_used(client_ip)
        
        return jsonify({
            'error': 'Usage limit reached',
            'message': f'Free clips exhausted for this device/IP. You have already used {total_ip_usage}/3 free credits. Please upgrade for $2 to unlock 15 reels.',
            'redirect': '/pricing',
            'ip_used': total_ip_usage
        }), 403
    
    task_id = str(uuid.uuid4())
    
    # Start processing in background
    thread = threading.Thread(
        target=pipeline.process_video,
        args=(data, task_id, user['id'])
    )
    thread.daemon = True
    thread.start()
    
    # Record IP usage for abuse tracking
    record_ip_usage(client_ip, user['id'])
    
    # Link user to this IP
    link_user_to_ip(user['id'], client_ip)
    
    # Update user free clips used
    if not user['is_premium']:
        new_used = (user['free_clips_used'] or 0) + 1
        update_free_clips(user['id'], new_used)
    
    # Calculate remaining
    final_remaining = min(user_remaining - 1, ip_remaining - 1) if user_remaining and ip_remaining else 0
    
    return jsonify({
        'task_id': task_id,
        'status': 'processing',
        'message': 'Video processing started',
        'remaining_clips': max(0, final_remaining),
        'ip_clips_used': get_ip_free_clips_used(client_ip)
    })

@bp.route('/status/<task_id>')
def get_status(task_id):
    """Get processing status"""
    status = pipeline.get_status(task_id)
    return jsonify(status)

@bp.route('/download/<task_id>/<clip_id>')
def download_clip(task_id, clip_id):
    """Download processed clip"""
    clip_path = os.path.join(pipeline.output_dir, task_id, f"{clip_id}.mp4")
    if os.path.exists(clip_path):
        return send_from_directory(
            os.path.dirname(clip_path), 
            os.path.basename(clip_path), 
            as_attachment=True
        )
    return jsonify({'error': 'Clip not found'}), 404

@bp.route('/clips/<task_id>')
def list_clips(task_id):
    """List all generated clips for a task"""
    clips = pipeline.get_clips(task_id)
    return jsonify(clips)

# ========== AUTH ROUTES ==========

@bp.route('/api/register', methods=['POST'])
def api_register():
    data = request.get_json()
    
    client_ip = get_client_ip(request)
    
    # Rate limiting
    if not check_rate_limit(client_ip):
        return jsonify({'error': 'Too many requests. Please wait a minute.'}), 429
    
    # Device fingerprinting
    fingerprint = generate_device_fingerprint(request)
    record_device_fingerprint(client_ip, fingerprint)
    
    # Block if suspicious (too many devices)
    if is_suspicious_device(client_ip, fingerprint):
        return jsonify({
            'error': 'Suspicious activity detected from this device.',
            'require_captcha': True
        }), 403
    
    # Block registration if IP has already exhausted free credits
    ip_can_use, _ = can_ip_use_free_clips(client_ip)
    if not ip_can_use:
        return jsonify({
            'error': 'This device has already used its free credits. Please purchase a plan.'
        }), 403
    
    user_id, error = register_user(data.get('email'), data.get('password'))
    
    if error:
        return jsonify({'error': error}), 400
    
    user = get_user_by_id(user_id)
    login_user(user_id, user['email'])
    
    link_user_to_ip(user_id, client_ip)
    
    return jsonify({
        'success': True,
        'user': {'id': user_id, 'email': user['email']},
        'message': 'Account created successfully'
    })

@bp.route('/api/captcha', methods=['GET'])
def get_captcha():
    captcha_id, question = generate_captcha()
    return jsonify({'captcha_id': captcha_id, 'question': question})

@bp.route('/api/verify-captcha', methods=['POST'])
def verify_captcha_api():
    data = request.get_json()
    is_valid = verify_captcha(data.get('captcha_id'), data.get('answer'))
    return jsonify({'valid': is_valid})

@bp.route('/api/login', methods=['POST'])
def api_login():
    data = request.get_json()
    user = get_user_by_email(data.get('email'))
    
    if not user or not verify_password(data.get('password'), user['password_hash']):
        return jsonify({'error': 'Invalid email or password'}), 401
    
    login_user(user['id'], user['email'])
    
    return jsonify({
        'success': True,
        'user': {'id': user['id'], 'email': user['email'], 'is_premium': user['is_premium']}
    })

@bp.route('/api/logout', methods=['POST'])
def api_logout():
    logout_user()
    return jsonify({'success': True})

@bp.route('/api/me')
@login_required
def api_me():
    user = get_current_user()
    
    # Get client IP
    client_ip = request.headers.get('X-Forwarded-For', request.remote_addr)
    if client_ip and ',' in client_ip:
        client_ip = client_ip.split(',')[0].strip()
    
    can_generate, remaining = can_generate_clips(user['id'], client_ip)
    ip_used = get_ip_free_clips_used(client_ip) if client_ip else 0
    
    return jsonify({
        'user': {
            'id': user['id'],
            'email': user['email'],
            'is_premium': bool(user['is_premium']),
            'free_clips_used': user['free_clips_used'],
            'subscription_expires': user['subscription_expires']
        },
        'can_generate': can_generate,
        'remaining_clips': remaining,
        'ip_clips_used': ip_used,
        'ip_limit': 3
    })

# ========== PAYMENT ROUTES ==========

@bp.route('/api/create-checkout', methods=['POST'])
@login_required
def create_checkout():
    user = get_current_user()
    
    checkout_url, error = create_checkout_session(user['id'], user['email'])
    
    if error:
        return jsonify({'error': error}), 400
    
    return jsonify({'checkout_url': checkout_url})

@bp.route('/payment/success')
def payment_success():
    session_id = request.args.get('session_id')
    if session_id and verify_payment(session_id):
        return render_template('payment_success.html')
    return redirect('/pricing')

@bp.route('/payment/cancel')
def payment_cancel():
    return render_template('payment_cancel.html')

@bp.route('/api/stripe-webhook', methods=['POST'])
def stripe_webhook():
    payload = request.data
    sig_header = request.headers.get('Stripe-Signature')
    
    success, message = handle_stripe_webhook(payload, sig_header)
    
    if success:
        return '', 200
    return jsonify({'error': message}), 400
