import os
import json
import uuid
import time
import shutil
from datetime import datetime
import yt_dlp
import whisper
import librosa
import numpy as np
import ffmpeg
from dotenv import load_dotenv
from .claude_scorer import ClaudeScorer
from .video_processor import VideoProcessor
from .caption_generator import CaptionGenerator

load_dotenv()

class ReelSetPipeline:
    def __init__(self):
        self.tasks = {}
        self.base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.upload_dir = os.path.join(self.base_dir, 'uploads')
        self.output_dir = os.path.join(self.base_dir, 'clips')
        self.temp_dir = os.path.join(self.base_dir, 'temp')
        
        os.makedirs(self.upload_dir, exist_ok=True)
        os.makedirs(self.output_dir, exist_ok=True)
        os.makedirs(self.temp_dir, exist_ok=True)
        
        # Load Whisper model
        print("Loading Whisper model...")
        self.whisper_model = whisper.load_model("base")  # Use 'small' or 'medium' for better accuracy
        
        # Initialize components
        self.claude = ClaudeScorer()
        self.video_proc = VideoProcessor()
        self.caption_gen = CaptionGenerator()
        
        self.max_duration = int(os.getenv('MAX_VIDEO_DURATION', 3600))
        self.max_clips = int(os.getenv('MAX_CLIPS', 5))
        self.clip_min = int(os.getenv('CLIP_MIN_DURATION', 25))
        self.clip_max = int(os.getenv('CLIP_MAX_DURATION', 65))
    
    def get_status(self, task_id):
        return self.tasks.get(task_id, {'status': 'unknown'})
    
    def update_status(self, task_id, status, message="", progress=0, data=None):
        self.tasks[task_id] = {
            'status': status,
            'message': message,
            'progress': progress,
            'timestamp': datetime.now().isoformat(),
            'data': data or {}
        }
    
    def process_video(self, data, task_id, user_id=None):
        """Main pipeline execution"""
        try:
            self.update_status(task_id, 'started', 'Initializing...', 5)
            
            # Step 1: Download / Prepare video
            video_path, video_info = self._download_or_upload(data, task_id)
            
            # Step 2: Transcribe with Whisper
            self.update_status(task_id, 'transcribing', 'Transcribing audio...', 25)
            transcript = self._transcribe(video_path, task_id)
            
            # Step 3: Analyze audio energy
            self.update_status(task_id, 'analyzing', 'Analyzing audio energy...', 40)
            energy_data = self._analyze_audio_energy(video_path, task_id)
            
            # Step 4: Score segments with Claude
            self.update_status(task_id, 'scoring', 'Scoring segments with Claude AI...', 55)
            scored_segments = self.claude.score_segments(
                transcript, energy_data, video_info
            )
            
            # Step 5: Select best clips
            self.update_status(task_id, 'selecting', 'Selecting best clips...', 70)
            selected_clips = self._select_best_clips(scored_segments)
            
            # Step 6: Process each clip (crop + captions)
            self.update_status(task_id, 'processing_clips', 'Generating clips...', 80)
            processed_clips = self._generate_clips(
                video_path, selected_clips, transcript, task_id
            )
            
            # Record usage if user_id provided
            if user_id:
                from .database import record_usage
                record_usage(user_id, task_id, len(processed_clips))
            
            # Finalize
            self.update_status(task_id, 'completed', 'All clips ready!', 100, {
                'clips': processed_clips,
                'video_title': video_info.get('title', 'Unknown'),
                'total_clips': len(processed_clips)
            })
            
        except Exception as e:
            print(f"Error in pipeline: {str(e)}")
            self.update_status(task_id, 'error', f'Error: {str(e)}', 0)
    
    def _download_or_upload(self, data, task_id):
        """Download from YT or handle upload"""
        self.update_status(task_id, 'downloading', 'Downloading video...', 10)
        
        task_dir = os.path.join(self.temp_dir, task_id)
        os.makedirs(task_dir, exist_ok=True)
        
        if 'youtube_url' in data and data['youtube_url']:
            # YouTube download
            url = data['youtube_url'].strip()
            
            ydl_opts = {
                'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best',
                'outtmpl': os.path.join(task_dir, '%(title)s.%(ext)s'),
                'merge_output_format': 'mp4',
                'quiet': True,
                'no_warnings': True,
            }
            
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=True)
                video_path = ydl.prepare_filename(info)
                
                if not video_path.endswith('.mp4'):
                    video_path = video_path.rsplit('.', 1)[0] + '.mp4'
            
            return video_path, {
                'title': info.get('title', 'YouTube Video'),
                'duration': info.get('duration', 0),
                'uploader': info.get('uploader', 'Unknown'),
                'source': 'youtube'
            }
        
        elif 'file_path' in data:
            # Local upload (for Termux or direct)
            src_path = data['file_path']
            filename = os.path.basename(src_path)
            video_path = os.path.join(task_dir, filename)
            shutil.copy(src_path, video_path)
            
            return video_path, {
                'title': filename,
                'duration': 0,
                'source': 'upload'
            }
        
        else:
            raise ValueError("No YouTube URL or file provided")
    
    def _transcribe(self, video_path, task_id):
        """Transcribe video using Whisper"""
        result = self.whisper_model.transcribe(
            video_path, 
            word_timestamps=True,
            verbose=False
        )
        
        # Structure transcript with word-level timestamps
        transcript = {
            'text': result['text'],
            'segments': []
        }
        
        for seg in result['segments']:
            segment = {
                'start': seg['start'],
                'end': seg['end'],
                'text': seg['text'].strip(),
                'words': []
            }
            
            if 'words' in seg:
                for word in seg['words']:
                    segment['words'].append({
                        'word': word['word'],
                        'start': word['start'],
                        'end': word['end'],
                        'probability': word.get('probability', 0.9)
                    })
            
            transcript['segments'].append(segment)
        
        # Save transcript for debugging
        transcript_path = os.path.join(self.temp_dir, task_id, 'transcript.json')
        with open(transcript_path, 'w') as f:
            json.dump(transcript, f, indent=2)
        
        return transcript
    
    def _analyze_audio_energy(self, video_path, task_id):
        """Analyze audio energy spikes using librosa"""
        # Extract audio
        y, sr = librosa.load(video_path, sr=22050)
        
        # Compute energy (RMS)
        hop_length = 512
        frame_length = 1024
        rms = librosa.feature.rms(y=y, frame_length=frame_length, hop_length=hop_length)[0]
        
        # Smooth RMS
        rms_smooth = np.convolve(rms, np.ones(10)/10, mode='same')
        
        # Normalize
        rms_norm = (rms_smooth - np.min(rms_smooth)) / (np.max(rms_smooth) - np.min(rms_smooth) + 1e-8)
        
        # Detect energy spikes
        energy_spikes = []
        threshold = np.percentile(rms_norm, 75)
        
        for i in range(len(rms_norm)):
            if rms_norm[i] > threshold:
                time_sec = i * hop_length / sr
                energy_spikes.append({
                    'time': time_sec,
                    'energy': float(rms_norm[i])
                })
        
        # Group spikes into clusters
        energy_windows = []
        if energy_spikes:
            current_window = [energy_spikes[0]]
            for spike in energy_spikes[1:]:
                if spike['time'] - current_window[-1]['time'] < 8:
                    current_window.append(spike)
                else:
                    if len(current_window) > 1:
                        energy_windows.append({
                            'start': current_window[0]['time'],
                            'end': current_window[-1]['time'],
                            'peak_energy': max(s['energy'] for s in current_window),
                            'avg_energy': float(np.mean([s['energy'] for s in current_window]))
                        })
                    current_window = [spike]
            
            # Add last window
            if len(current_window) > 1:
                energy_windows.append({
                    'start': current_window[0]['time'],
                    'end': current_window[-1]['time'],
                    'peak_energy': max(s['energy'] for s in current_window),
                    'avg_energy': float(np.mean([s['energy'] for s in current_window]))
                })
        
        return {
            'energy_windows': energy_windows,
            'rms_data': rms_norm.tolist()[:200],  # Sample for frontend
            'duration': librosa.get_duration(y=y, sr=sr)
        }
    
    def _select_best_clips(self, scored_segments):
        """Select top 3-5 clips based on Claude scores"""
        # Sort by score descending
        sorted_segments = sorted(
            scored_segments, 
            key=lambda x: x.get('hook_score', 0), 
            reverse=True
        )
        
        selected = []
        used_ranges = []
        
        for seg in sorted_segments:
            if len(selected) >= self.max_clips:
                break
            
            start = seg['start']
            end = seg['end']
            duration = end - start
            
            # Ensure clip is within range
            if duration < self.clip_min or duration > self.clip_max:
                continue
            
            # Check overlap
            overlaps = False
            for used in used_ranges:
                if not (end <= used[0] or start >= used[1]):
                    overlaps = True
                    break
            
            if not overlaps:
                selected.append(seg)
                used_ranges.append((start, end))
        
        return selected
    
    def _generate_clips(self, video_path, selected_clips, transcript, task_id):
        """Generate final 9:16 clips with captions"""
        task_output_dir = os.path.join(self.output_dir, task_id)
        os.makedirs(task_output_dir, exist_ok=True)
        
        processed = []
        
        for idx, clip in enumerate(selected_clips):
            clip_id = f"clip_{idx+1}"
            output_path = os.path.join(task_output_dir, f"{clip_id}.mp4")
            
            self.update_status(
                task_id, 'processing_clips', 
                f'Processing clip {idx+1}/{len(selected_clips)}...', 
                80 + (idx * 4)
            )
            
            # Crop to 9:16 vertical
            self.video_proc.crop_to_vertical(
                video_path, 
                output_path, 
                clip['start'], 
                clip['end']
            )
            
            # Generate captions
            clip_transcript = self._extract_clip_transcript(transcript, clip['start'], clip['end'])
            
            # Burn captions with CapCut-style word-pop
            captioned_path = self.caption_gen.burn_captions(
                output_path, 
                clip_transcript, 
                task_output_dir,
                clip_id
            )
            
            # Move final file
            final_path = os.path.join(task_output_dir, f"{clip_id}_final.mp4")
            if os.path.exists(captioned_path):
                shutil.move(captioned_path, final_path)
            else:
                final_path = output_path
            
            processed.append({
                'id': clip_id,
                'start': clip['start'],
                'end': clip['end'],
                'duration': clip['end'] - clip['start'],
                'score': clip.get('hook_score', 0),
                'reason': clip.get('reason', ''),
                'file': f"{clip_id}_final.mp4",
                'download_url': f"/download/{task_id}/{clip_id}_final"
            })
        
        return processed
    
    def _extract_clip_transcript(self, full_transcript, start_time, end_time):
        """Extract relevant transcript segment for the clip"""
        clip_words = []
        
        for segment in full_transcript.get('segments', []):
            for word in segment.get('words', []):
                if word['start'] >= start_time and word['end'] <= end_time:
                    clip_words.append(word)
        
        return {
            'words': clip_words,
            'text': ' '.join([w['word'] for w in clip_words])
        }
    
    def get_clips(self, task_id):
        """Return list of clips for frontend"""
        status = self.get_status(task_id)
        if status.get('status') == 'completed':
            return status.get('data', {}).get('clips', [])
        return []
