import sqlite3
import os
from datetime import datetime, timedelta

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'reelset.db')

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    cursor = conn.cursor()
    
    # Users table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            is_premium BOOLEAN DEFAULT FALSE,
            subscription_expires TIMESTAMP,
            free_clips_used INTEGER DEFAULT 0
        )
    ''')
    
    # Usage tracking
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS usage (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            task_id TEXT NOT NULL,
            clips_generated INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    
    # Payments table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS payments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            stripe_session_id TEXT UNIQUE,
            amount INTEGER,
            status TEXT,
            clips_purchased INTEGER DEFAULT 15,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    
    # IP-based free credit limits (anti-abuse)
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS ip_limits (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ip_address TEXT UNIQUE NOT NULL,
            free_clips_used INTEGER DEFAULT 0,
            first_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_used TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # IP to user mapping (for tracking multiple accounts from same IP)
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS ip_users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ip_address TEXT NOT NULL,
            user_id INTEGER NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    
    conn.commit()
    conn.close()
    print("✅ Database initialized with IP security")

def create_user(email, password_hash):
    conn = get_db()
    try:
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO users (email, password_hash) VALUES (?, ?)",
            (email, password_hash)
        )
        user_id = cursor.lastrowid
        conn.commit()
        return user_id
    except sqlite3.IntegrityError:
        return None
    finally:
        conn.close()

def get_user_by_email(email):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE email = ?", (email,))
    user = cursor.fetchone()
    conn.close()
    return user

def get_user_by_id(user_id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
    user = cursor.fetchone()
    conn.close()
    return user

def update_free_clips(user_id, clips_used):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE users SET free_clips_used = ? WHERE id = ?",
        (clips_used, user_id)
    )
    conn.commit()
    conn.close()

def record_usage(user_id, task_id, clips_count):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO usage (user_id, task_id, clips_generated) VALUES (?, ?, ?)",
        (user_id, task_id, clips_count)
    )
    conn.commit()
    conn.close()

def can_generate_clips(user_id, ip_address=None):
    """Check if user can generate clips (free tier or paid) with IP abuse protection"""
    user = get_user_by_id(user_id)
    if not user:
        return False, 0
    
    # Check if user has active premium
    if user['is_premium'] and user['subscription_expires']:
        expires = datetime.fromisoformat(user['subscription_expires'])
        if expires > datetime.now():
            return True, 15  # Paid user can generate 15 clips
    
    # IP-level abuse protection (even with multiple accounts / temp mails)
    if ip_address:
        ip_free_used = get_ip_free_clips_used(ip_address)
        
        # Global IP limit: 3 clips per IP across ALL accounts
        if ip_free_used >= 3:
            return False, 0
        
        # Also check total usage from all users on this IP
        total_ip_usage = get_total_free_clips_by_ip(ip_address)
        if total_ip_usage >= 3:
            return False, 0
    
    # Free tier: 3 clips lifetime per user
    free_used = user['free_clips_used'] or 0
    if free_used < 3:
        return True, 3 - free_used
    
    return False, 0

def add_premium(user_id, days=30):
    """Grant premium access"""
    conn = get_db()
    cursor = conn.cursor()
    expires = datetime.now() + timedelta(days=days)
    cursor.execute(
        "UPDATE users SET is_premium = TRUE, subscription_expires = ? WHERE id = ?",
        (expires.isoformat(), user_id)
    )
    conn.commit()
    conn.close()

def record_payment(user_id, session_id, amount, clips=15):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute(
        """INSERT INTO payments (user_id, stripe_session_id, amount, status, clips_purchased) 
           VALUES (?, ?, ?, ?, ?)""",
        (user_id, session_id, amount, 'pending', clips)
    )
    conn.commit()
    conn.close()

def complete_payment(session_id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE payments SET status = 'completed' WHERE stripe_session_id = ?",
        (session_id,)
    )
    conn.commit()
    conn.close()
    
    # Get user_id from payment
    cursor.execute("SELECT user_id FROM payments WHERE stripe_session_id = ?", (session_id,))
    row = cursor.fetchone()
    if row:
        add_premium(row['user_id'], days=30)
    conn.close()

# ==================== IP SECURITY FUNCTIONS ====================

def get_client_ip():
    """Get real client IP (works behind proxies)"""
    # This is a placeholder — actual IP comes from Flask request in routes
    return None

def record_ip_usage(ip_address, user_id=None):
    """Record IP usage and link to user"""
    conn = get_db()
    cursor = conn.cursor()
    
    # Record/update IP limit
    cursor.execute('''
        INSERT INTO ip_limits (ip_address, free_clips_used, last_used) 
        VALUES (?, 1, CURRENT_TIMESTAMP)
        ON CONFLICT(ip_address) DO UPDATE SET 
            free_clips_used = free_clips_used + 1,
            last_used = CURRENT_TIMESTAMP
    ''', (ip_address,))
    
    # Link IP to user if provided
    if user_id:
        cursor.execute('''
            INSERT OR IGNORE INTO ip_users (ip_address, user_id) 
            VALUES (?, ?)
        ''', (ip_address, user_id))
    
    conn.commit()
    conn.close()

def get_ip_free_clips_used(ip_address):
    """Get how many free clips this IP has already used"""
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT free_clips_used FROM ip_limits WHERE ip_address = ?", (ip_address,))
    row = cursor.fetchone()
    conn.close()
    return row['free_clips_used'] if row else 0

def can_ip_use_free_clips(ip_address):
    """Check if this IP can still use free credits (global limit: 3 per IP)"""
    used = get_ip_free_clips_used(ip_address)
    return used < 3, 3 - used

def link_user_to_ip(user_id, ip_address):
    """Link a user account to an IP address"""
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT OR IGNORE INTO ip_users (ip_address, user_id) 
        VALUES (?, ?)
    ''', (ip_address, user_id))
    conn.commit()
    conn.close()

def get_users_from_ip(ip_address):
    """Get all users that have been created from this IP"""
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT u.id, u.email, u.free_clips_used 
        FROM ip_users iu 
        JOIN users u ON iu.user_id = u.id 
        WHERE iu.ip_address = ?
    ''', (ip_address,))
    users = cursor.fetchall()
    conn.close()
    return users

def get_total_free_clips_by_ip(ip_address):
    """Calculate total free clips used across all accounts from this IP"""
    users = get_users_from_ip(ip_address)
    total = sum(u['free_clips_used'] or 0 for u in users)
    return total

init_db()
