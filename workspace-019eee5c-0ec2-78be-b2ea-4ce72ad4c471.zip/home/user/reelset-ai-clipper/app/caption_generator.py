import os
import json
import subprocess
from moviepy.editor import VideoFileClip, TextClip, CompositeVideoClip
import tempfile
import shutil

class CaptionGenerator:
    def __init__(self):
        self.font = "Arial"  # Can be changed to 'Impact' or system font
        self.font_size = 72
        self.stroke_width = 4
    
    def burn_captions(self, video_path, clip_transcript, output_dir, clip_id):
        """
        Burn CapCut-style word-pop captions into the video.
        Uses MoviePy for dynamic word highlighting.
        """
        try:
            # Create temporary directory
            temp_dir = os.path.join(output_dir, f"temp_{clip_id}")
            os.makedirs(temp_dir, exist_ok=True)
            
            # Get words from transcript
            words = clip_transcript.get('words', [])
            
            if not words:
                # Fallback to simple subtitle
                return self._add_simple_subtitles(video_path, clip_transcript.get('text', ''), output_dir, clip_id)
            
            # Load original video
            video = VideoFileClip(video_path)
            
            # Prepare text clips for each word
            text_clips = []
            
            for word_data in words:
                word = word_data.get('word', '').strip()
                if not word:
                    continue
                
                start = word_data.get('start', 0) - video.start  # Relative time
                end = word_data.get('end', start + 1.5) - video.start
                
                if start < 0:
                    start = 0
                
                # Create CapCut-style text clip
                txt_clip = TextClip(
                    word,
                    fontsize=self.font_size,
                    color='white',
                    stroke_color='black',
                    stroke_width=self.stroke_width,
                    font=self.font,
                    method='label'
                )
                
                # Position at bottom center with slight offset
                txt_clip = txt_clip.set_position(('center', 0.85), relative=True)
                txt_clip = txt_clip.set_start(max(0, start))
                txt_clip = txt_clip.set_duration(max(0.1, end - start))
                
                # Add subtle pop effect (scale animation)
                txt_clip = txt_clip.resize(lambda t: 1 + 0.08 * (1 - abs(t - (end - start) / 2) / ((end - start) / 2)) if (end - start) > 0.3 else 1)
                
                text_clips.append(txt_clip)
            
            # Composite all text on video
            if text_clips:
                final = CompositeVideoClip([video] + text_clips)
            else:
                final = video
            
            # Export final clip
            final_output = os.path.join(output_dir, f"{clip_id}_captioned.mp4")
            
            final.write_videofile(
                final_output,
                codec="libx264",
                audio_codec="aac",
                fps=30,
                preset='medium',
                bitrate="2500k",
                verbose=False,
                logger=None
            )
            
            # Cleanup
            video.close()
            final.close()
            
            # Remove temp dir
            if os.path.exists(temp_dir):
                shutil.rmtree(temp_dir)
            
            return final_output
            
        except Exception as e:
            print(f"Caption generation error: {e}")
            # Fallback: return original video
            return video_path
    
    def _add_simple_subtitles(self, video_path, text, output_dir, clip_id):
        """Simple subtitle fallback if word-level fails"""
        try:
            video = VideoFileClip(video_path)
            
            # Create subtitle clip
            subtitle = TextClip(
                text[:80] + ("..." if len(text) > 80 else ""),
                fontsize=48,
                color='white',
                stroke_color='black',
                stroke_width=3,
                font=self.font,
                method='caption',
                size=(video.w - 80, None)
            )
            
            subtitle = subtitle.set_position(('center', 0.88), relative=True)
            subtitle = subtitle.set_duration(video.duration)
            
            final = CompositeVideoClip([video, subtitle])
            
            output_path = os.path.join(output_dir, f"{clip_id}_captioned.mp4")
            
            final.write_videofile(
                output_path,
                codec="libx264",
                audio_codec="aac",
                fps=24,
                preset='fast',
                verbose=False,
                logger=None
            )
            
            video.close()
            final.close()
            
            return output_path
            
        except Exception as e:
            print(f"Simple subtitle error: {e}")
            return video_path
