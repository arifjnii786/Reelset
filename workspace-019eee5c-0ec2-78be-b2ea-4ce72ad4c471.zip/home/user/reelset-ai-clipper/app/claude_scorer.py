import os
import json
import requests
from dotenv import load_dotenv

load_dotenv()

class ClaudeScorer:
    def __init__(self):
        self.api_key = os.getenv('CLAUDE_API_KEY')
        self.api_url = "https://api.anthropic.com/v1/messages"
        self.model = "claude-3-5-sonnet-20241022"
    
    def score_segments(self, transcript, energy_data, video_info):
        """Score video segments using Claude for hook potential"""
        
        # Prepare context for Claude
        context = self._prepare_context(transcript, energy_data, video_info)
        
        if not self.api_key:
            print("⚠️ No Claude API key found. Using fallback scoring.")
            return self._fallback_scoring(transcript, energy_data)
        
        prompt = f"""You are an expert short-form video editor for YouTube Shorts, TikTok and Instagram Reels.

Analyze the following video transcript and audio energy data. Identify the 3-8 most viral-potential segments that would make the best 25-65 second clips.

For each segment you recommend, provide:
1. Start time (in seconds)
2. End time (in seconds)
3. Hook score (0-100) — how strong the hook is
4. Reason (1-2 sentences why this clip is compelling)

**Video Info:**
Title: {video_info.get('title', 'Unknown')}
Duration: {video_info.get('duration', 0)} seconds

**Transcript (with timestamps):**
{context['transcript_summary']}

**Audio Energy Spikes:**
{context['energy_summary']}

Respond ONLY with valid JSON in this exact format:
[
  {{
    "start": <float>,
    "end": <float>,
    "hook_score": <int>,
    "reason": "<string>"
  }},
  ...
]

Only include segments that have strong hook potential. Prioritize:
- Strong opening lines / questions
- High energy moments
- Emotional peaks
- Surprising / shocking content
- Clear narrative arcs
"""

        try:
            response = requests.post(
                self.api_url,
                headers={
                    "x-api-key": self.api_key,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json"
                },
                json={
                    "model": self.model,
                    "max_tokens": 2000,
                    "messages": [
                        {
                            "role": "user",
                            "content": prompt
                        }
                    ]
                },
                timeout=60
            )
            
            if response.status_code == 200:
                result = response.json()
                content = result['content'][0]['text']
                
                # Parse JSON from response
                try:
                    # Clean the response if it has markdown code blocks
                    if '```json' in content:
                        content = content.split('```json')[1].split('```')[0]
                    elif '```' in content:
                        content = content.split('```')[1]
                    
                    segments = json.loads(content.strip())
                    
                    # Validate segments
                    valid_segments = []
                    for seg in segments:
                        if all(k in seg for k in ['start', 'end', 'hook_score']):
                            valid_segments.append({
                                'start': float(seg['start']),
                                'end': float(seg['end']),
                                'hook_score': int(seg['hook_score']),
                                'reason': seg.get('reason', 'High potential clip')
                            })
                    
                    return valid_segments if valid_segments else self._fallback_scoring(transcript, energy_data)
                
                except json.JSONDecodeError:
                    print("Failed to parse Claude response. Using fallback.")
                    return self._fallback_scoring(transcript, energy_data)
            else:
                print(f"Claude API error: {response.status_code}")
                return self._fallback_scoring(transcript, energy_data)
        
        except Exception as e:
            print(f"Claude scoring error: {e}")
            return self._fallback_scoring(transcript, energy_data)
    
    def _prepare_context(self, transcript, energy_data, video_info):
        """Prepare condensed context for Claude"""
        
        # Summarize transcript with segment timestamps
        transcript_lines = []
        for i, seg in enumerate(transcript.get('segments', [])[:30]):  # Limit segments
            transcript_lines.append(
                f"[{seg['start']:.1f}s - {seg['end']:.1f}s]: {seg['text'][:120]}"
            )
        
        transcript_summary = "\n".join(transcript_lines)
        
        # Summarize energy
        energy_windows = energy_data.get('energy_windows', [])
        energy_summary = ""
        if energy_windows:
            energy_summary = "\n".join([
                f"[{w['start']:.1f}s - {w['end']:.1f}s] Energy: {w['peak_energy']:.2f}"
                for w in energy_windows[:12]
            ])
        else:
            energy_summary = "No significant energy spikes detected."
        
        return {
            'transcript_summary': transcript_summary,
            'energy_summary': energy_summary
        }
    
    def _fallback_scoring(self, transcript, energy_data):
        """Fallback scoring when Claude API is unavailable"""
        segments = []
        energy_windows = energy_data.get('energy_windows', [])
        
        # Use energy windows as potential clips
        for i, window in enumerate(energy_windows[:6]):
            duration = window['end'] - window['start']
            
            # Expand slightly for context
            start = max(0, window['start'] - 3)
            end = window['end'] + 6
            
            # Adjust to target duration
            if end - start < 25:
                end = start + 35
            elif end - start > 65:
                end = start + 55
            
            segments.append({
                'start': round(start, 1),
                'end': round(end, 1),
                'hook_score': int(65 + (window['peak_energy'] * 25)),
                'reason': 'High energy moment with strong audio peak'
            })
        
        # If not enough, add segments from transcript
        if len(segments) < 3:
            for i, seg in enumerate(transcript.get('segments', [])[:4]):
                if len(segments) >= 5:
                    break
                duration = seg['end'] - seg['start']
                if duration > 20:
                    segments.append({
                        'start': seg['start'],
                        'end': min(seg['end'] + 20, seg['start'] + 55),
                        'hook_score': 60 + (i * 5),
                        'reason': 'Strong narrative segment from transcript'
                    })
        
        return segments
