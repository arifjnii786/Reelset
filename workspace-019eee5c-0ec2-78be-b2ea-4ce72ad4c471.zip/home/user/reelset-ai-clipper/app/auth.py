import hashlib
import os
from functools import wraps
from flask import session, request, jsonify, redirect, url_for
from .database import get_user_by_email, create_user, get_user_by_id

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def verify_password(password, hashed):
    return hash_password(password) == hashed

def login_user(user_id, email):
    session['user_id'] = user_id
    session['email'] = email
    session.permanent = True

def logout_user():
    session.pop('user_id', None)
    session.pop('email', None)

def get_current_user():
    if 'user_id' not in session:
        return None
    return get_user_by_id(session['user_id'])

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            if request.is_json:
                return jsonify({'error': 'Authentication required', 'redirect': '/login'}), 401
            return redirect('/login')
        return f(*args, **kwargs)
    return decorated_function

def register_user(email, password):
    if not email or not password:
        return None, "Email and password required"
    
    if len(password) < 6:
        return None, "Password must be at least 6 characters"
    
    password_hash = hash_password(password)
    user_id = create_user(email, password_hash)
    
    if user_id:
        return user_id, None
    else:
        return None, "Email already registered"
