import time
import hashlib
import json
from collections import defaultdict
from datetime import datetime, timedelta

# In-memory rate limiting store
rate_limits = defaultdict(list)
device_fingerprints = {}

# Simple rate limiter: max 5 requests per minute per IP
RATE_LIMIT_WINDOW = 60  # seconds
RATE_LIMIT_MAX = 5

def get_client_ip(request):
    """Get real client IP"""
    ip = request.headers.get('X-Forwarded-For', request.remote_addr)
    if ip and ',' in ip:
        ip = ip.split(',')[0].strip()
    return ip or 'unknown'

def check_rate_limit(ip):
    """Simple rate limiting"""
    now = time.time()
    # Clean old entries
    rate_limits[ip] = [t for t in rate_limits[ip] if now - t < RATE_LIMIT_WINDOW]
    
    if len(rate_limits[ip]) >= RATE_LIMIT_MAX:
        return False
    
    rate_limits[ip].append(now)
    return True

def generate_device_fingerprint(request):
    """Generate a simple device fingerprint from headers"""
    user_agent = request.headers.get('User-Agent', '')
    accept = request.headers.get('Accept', '')
    accept_language = request.headers.get('Accept-Language', '')
    
    raw = f"{user_agent}|{accept}|{accept_language}"
    fingerprint = hashlib.sha256(raw.encode()).hexdigest()[:16]
    
    return fingerprint

def record_device_fingerprint(ip, fingerprint):
    """Store device fingerprint per IP"""
    if ip not in device_fingerprints:
        device_fingerprints[ip] = []
    
    if fingerprint not in device_fingerprints[ip]:
        device_fingerprints[ip].append(fingerprint)
    
    # Limit to 5 unique devices per IP
    if len(device_fingerprints[ip]) > 5:
        device_fingerprints[ip] = device_fingerprints[ip][-5:]

def is_suspicious_device(ip, fingerprint):
    """Check if device fingerprint looks suspicious"""
    if ip not in device_fingerprints:
        return False
    
    # Too many different fingerprints from same IP = suspicious
    return len(device_fingerprints[ip]) > 4

# Simple CAPTCHA system (math based)
import random

captcha_store = {}

def generate_captcha():
    """Generate a simple math CAPTCHA"""
    a = random.randint(10, 50)
    b = random.randint(1, 20)
    answer = a + b
    captcha_id = hashlib.md5(f"{a}{b}{time.time()}".encode()).hexdigest()[:8]
    
    captcha_store[captcha_id] = {
        'answer': answer,
        'created': time.time(),
        'attempts': 0
    }
    
    # Clean old captchas
    for cid in list(captcha_store.keys()):
        if time.time() - captcha_store[cid]['created'] > 300:  # 5 min expiry
            del captcha_store[cid]
    
    return captcha_id, f"{a} + {b} = ?"

def verify_captcha(captcha_id, user_answer):
    """Verify CAPTCHA answer"""
    if captcha_id not in captcha_store:
        return False
    
    data = captcha_store[captcha_id]
    data['attempts'] += 1
    
    if data['attempts'] > 3:
        del captcha_store[captcha_id]
        return False
    
    correct = str(data['answer']) == str(user_answer).strip()
    
    if correct:
        del captcha_store[captcha_id]
    
    return correct

def get_captcha_question(captcha_id):
    return captcha_store.get(captcha_id, {}).get('question', None)