import os
import stripe
from flask import request, jsonify
from .database import record_payment, complete_payment, get_user_by_id

stripe.api_key = os.getenv('STRIPE_SECRET_KEY', 'sk_test_your_key_here')

def create_checkout_session(user_id, email):
    """Create a Stripe checkout session for $2 / 15 reels"""
    
    try:
        checkout_session = stripe.checkout.Session.create(
            payment_method_types=['card'],
            line_items=[{
                'price_data': {
                    'currency': 'usd',
                    'product_data': {
                        'name': 'ReelSet AI - 15 Reels Pack',
                        'description': 'Unlock 15 high-quality AI-generated shorts',
                    },
                    'unit_amount': 200,  # $2.00
                },
                'quantity': 1,
            }],
            mode='payment',
            success_url=request.host_url + 'payment/success?session_id={CHECKOUT_SESSION_ID}',
            cancel_url=request.host_url + 'payment/cancel',
            customer_email=email,
            metadata={
                'user_id': str(user_id),
                'clips': '15'
            }
        )
        
        # Record pending payment
        record_payment(user_id, checkout_session.id, 200, 15)
        
        return checkout_session.url, None
    
    except Exception as e:
        return None, str(e)

def handle_stripe_webhook(payload, sig_header):
    """Handle Stripe webhook events"""
    webhook_secret = os.getenv('STRIPE_WEBHOOK_SECRET')
    
    try:
        event = stripe.Webhook.construct_event(
            payload, sig_header, webhook_secret
        )
    except ValueError:
        return False, "Invalid payload"
    except stripe.error.SignatureVerificationError:
        return False, "Invalid signature"
    
    if event['type'] == 'checkout.session.completed':
        session = event['data']['object']
        session_id = session['id']
        
        # Complete the payment and grant premium
        complete_payment(session_id)
        
        return True, "Payment completed"
    
    return True, "Event ignored"

def verify_payment(session_id):
    """Verify payment status"""
    try:
        session = stripe.checkout.Session.retrieve(session_id)
        return session.payment_status == 'paid'
    except:
        return False
